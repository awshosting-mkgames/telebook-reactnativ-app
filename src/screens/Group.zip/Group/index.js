import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useContext, useEffect, useState } from 'react';
import {
    ActivityIndicator, Alert, Platform,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useSelector } from 'react-redux';
import { ThemeContext } from '../../components/ThemeContext';
import apiService from '../../services/apiService';

// ── Components ────────────────────────────────────────────────────────────────
import AddMemberModal from './components/AddMemberModal';
import EditNamePopup from './components/EditNamePopup';
import GroupFooter from './components/GroupFooter';
import GroupHeader from './components/GroupHeader';
import GroupMedia from './components/GroupMedia';
import GroupMembers from './components/GroupMembers';
import { getImageUrl } from './components/helpers';
import MediaSlider from './components/MediaSlider';

export default function GroupScreen({ navigation, route }) {
    const { chatId } = route.params;
    const { theme }  = useContext(ThemeContext);

    const maniAllData = useSelector((state) => state.totalappData);
    const MY_USER_ID  = maniAllData?.userId ?? '';

    const [groupDetails,    setGroupDetails]    = useState(null);
    const [mediaDetails,    setMediaDetails]    = useState(null);
    const [loading,         setLoading]         = useState(true);
    const [showAllMembers,  setShowAllMembers]  = useState(false);
    const [editNameVisible,  setEditNameVisible]  = useState(false);
    const [mediaSliderIdx,   setMediaSliderIdx]   = useState(null);  // null = closed
    const [addMemberVisible, setAddMemberVisible] = useState(false);


    useEffect(() => { fetchGroupDetails(); }, []);

    const fetchGroupDetails = async () => {
        try {
            setLoading(true);
            const res = await apiService({ method: 'GET', endpoint: `chats/group/${chatId}/info` });
            console.log("res____________",res)
            if (res?.success) {
                setGroupDetails(res?.data?.group);
                setMediaDetails(res?.data?.media);
            }
        } catch (e) {
            console.error('Group fetch error:', e);
        } finally {
            setLoading(false);
        }
    };


    const handleSaveName = async (newName) => {
        try {
            const res = await apiService({
                method:   'PUT',
                endpoint: 'chats/group/rename',
                data:     { chatId, chatName: newName },
            });
            if (res?.success) {
                setGroupDetails(prev => ({ ...prev, chatName: newName }));
                setEditNameVisible(false);
            } else {
                Alert.alert('Error', res?.message || 'Name update nahi hua');
            }
        } catch (e) { Alert.alert('Error', e.message); }
    };


    const handleChangeImage = async () => {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') return Alert.alert('Permission chahiye', 'Gallery allow karo');

        const res = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            quality:    0.8,
        });
        if (res.canceled) return;

        try {
            const asset = res.assets[0];
            const fd    = new FormData();
            fd.append('chatId',    chatId);
            fd.append('groupIcon', {
                uri:  Platform.OS === 'android' ? asset.uri : asset.uri.replace('file://', ''),
                name: `group_${Date.now()}.jpg`,
                type: 'image/jpeg',
            });
            const apiRes = await apiService({
                method:   'PUT',
                endpoint: 'chats/group/update',
                data:     fd,
                headers:  { 'Content-Type': 'multipart/form-data' },
            });
            if (apiRes?.success) {
                setGroupDetails(prev => ({ ...prev, groupIcon: apiRes?.data?.groupIcon || prev.groupIcon }));
                Alert.alert('Done', 'Group photo update ho gaya!');
            } else {
                Alert.alert('Error', apiRes?.message || 'Photo update nahi hui');
            }
        } catch (e) { Alert.alert('Error', e.message); }
    };


    const handleRemoveMember = (member) => {
        Alert.alert(
            'Remove Member',
            `${member.name} ko group se remove karein?`,
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Remove', style: 'destructive',
                    onPress: async () => {
                        try {
                            const res = await apiService({
                                method:   'PUT',
                                endpoint: 'chats/group/remove',
                                data:     { chatId, userId: member._id },
                            });
                            if (res?.success) {
                                setGroupDetails(prev => ({
                                    ...prev,
                                    members:      prev.members.filter(m => m._id !== member._id),
                                    totalMembers: (prev.totalMembers || 1) - 1,
                                }));
                            } else {
                                Alert.alert('Error', res?.message || 'Remove nahi hua');
                            }
                        } catch (e) { Alert.alert('Error', e.message); }
                    },
                },
            ]
        );
    };

    // 4. Exit group
    const handleExitGroup = () => {
        Alert.alert(
            'Exit Group',
            `"${groupDetails?.chatName}" group leave karein?`,
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Exit', style: 'destructive',
                    onPress: async () => {
                        try {
                            const res = await apiService({
                                method: 'PUT', endpoint: 'chats/group/leave', data: { chatId },
                            });
                            if (res?.success) navigation.goBack();
                            else Alert.alert('Error', res?.message || 'Leave nahi hua');
                        } catch (e) { Alert.alert('Error', e.message); }
                    },
                },
            ]
        );
    };

    // 5. Delete group (admin only)
    const handleDeleteGroup = () => {
        Alert.alert(
            'Delete Group',
            `"${groupDetails?.chatName}" permanently delete ho jaayega. Sure hain?`,
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Delete', style: 'destructive',
                    onPress: async () => {
                        try {
                            const res = await apiService({
                                method: 'DELETE', endpoint: `chats/${chatId}`,
                            });
                            if (res?.success) navigation.goBack();
                            else Alert.alert('Error', res?.message || 'Delete nahi hua');
                        } catch (e) { Alert.alert('Error', e.message); }
                    },
                },
            ]
        );
    };
    const onPriveChat =  async()=>{
         try {
            const res = await apiService({
                method: 'DELETE', endpoint: `chats/${chatId}`,
            });
            if (res?.success) navigation.goBack();
            else Alert.alert('Error', res?.message || 'Delete nahi hua');
        } catch (e) { Alert.alert('Error', e.message); }
    }

    // ── Derived ───────────────────────────────────────────────────────────────
    const isAdmin      = groupDetails?.isAdmin ?? false;
    const existingIds  = (groupDetails?.members || []).map(m => m._id);
    const mediaImages  = mediaDetails?.images?.items || [];

    // ── Loading ───────────────────────────────────────────────────────────────
    if (loading) {
        return (
            <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
                <View style={styles.header}>
                    <TouchableOpacity onPress={() => navigation.goBack()}>
                        <Ionicons name="arrow-back" size={24} color="white" />
                    </TouchableOpacity>
                </View>
                <View style={styles.loaderWrap}>
                    <ActivityIndicator size="large" color="#3498db" />
                    <Text style={[styles.loaderText, { color: theme.text }]}>Loading group info...</Text>
                </View>
            </SafeAreaView>
        );
    }

    // ── Render ────────────────────────────────────────────────────────────────
    return (
        <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>

            {/* Top bar */}
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Ionicons name="arrow-back" size={24} color="white" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Group Info</Text>
            </View>

            {/* ── Popups ── */}
            <EditNamePopup
                visible={editNameVisible}
                currentName={groupDetails?.chatName}
                onClose={() => setEditNameVisible(false)}
                onSave={handleSaveName}
            />

            <MediaSlider
                visible={mediaSliderIdx !== null}
                items={mediaImages}
                startIndex={mediaSliderIdx ?? 0}
                onClose={() => setMediaSliderIdx(null)}
                getUrl={getImageUrl}
            />

            <AddMemberModal
                visible={addMemberVisible}
                onClose={() => setAddMemberVisible(false)}
                chatId={chatId}
                existingMemberIds={existingIds}
                onAdded={fetchGroupDetails}
            />

            {/* ── Scrollable body ── */}
            <ScrollView showsVerticalScrollIndicator={false}>

                <GroupHeader
                    groupDetails={groupDetails}
                    theme={theme}
                    onImagePress={handleChangeImage}
                    onNamePress={() => setEditNameVisible(true)}
                    onAddMember={() => setAddMemberVisible(true)}
                />

                <View style={[styles.divider, { backgroundColor: theme.dividerColor }]} />

                <GroupMedia
                    mediaDetails={mediaDetails}
                    theme={theme}
                    onMediaPress={(idx) => setMediaSliderIdx(idx)}
                />

                <View style={[styles.divider, { backgroundColor: theme.dividerColor }]} />

                <GroupMembers
                    groupDetails={groupDetails}
                    theme={theme}
                    MY_USER_ID={MY_USER_ID}
                    showAllMembers={showAllMembers}
                    setShowAllMembers={setShowAllMembers}
                    onAddMember={() => setAddMemberVisible(true)}
                    onRemoveMember={handleRemoveMember}
                />

                <View style={[styles.divider, { backgroundColor: theme.dividerColor }]} />

                <GroupFooter
                    theme={theme}
                    isAdmin={isAdmin}
                    onExitGroup={handleExitGroup}
                    onDeleteGroup={handleDeleteGroup}
                    onPriveChat={onPriveChat}
                />

            </ScrollView>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container:   { flex: 1 },
    header:      { height: 60, backgroundColor: '#3498db', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 15, gap: 14 },
    headerTitle: { color: '#fff', fontSize: 18, fontWeight: '600' },
    loaderWrap:  { flex: 1, justifyContent: 'center', alignItems: 'center' },
    loaderText:  { marginTop: 12, fontSize: 15, color: '#555' },
    divider:     { height: 8, backgroundColor: '#f6f6f6', marginVertical: 5 },
});
