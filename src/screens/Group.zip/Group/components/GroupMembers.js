import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import {
    Image,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import { getImageUrl } from './helpers';

const GroupMembers = ({
    groupDetails,
    theme,
    MY_USER_ID,
    showAllMembers,
    setShowAllMembers,
    onAddMember,
    onRemoveMember,
}) => {
    const { t } = useTranslation();

    const isAdmin       = groupDetails?.isAdmin ?? false;
    const isAdminMember = (memberId) => groupDetails?.admins?.some(a => a._id === memberId);

    const displayedMembers = showAllMembers
        ? groupDetails?.members || []
        : (groupDetails?.members || []).slice(0, 5);

    return (
        <View>
            {/* Section header */}
            <View style={styles.sectionHeader}>
                <Text style={[styles.sectionTitle, { color: theme.text }]}>
                    {groupDetails?.totalMembers || 0} members
                </Text>
              
            </View>

            {/* Admin shortcuts */}
            {isAdmin && (
                <>
                    <TouchableOpacity style={styles.row} onPress={onAddMember}>
                        <View style={styles.iconCircle}>
                            <Ionicons name="person-add" size={20} color="white" />
                        </View>
                        <Text style={[styles.shortcutText, { color: theme.text }]}>Add members</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.row}>
                        <View style={styles.iconCircle}>
                            <Ionicons name="link" size={20} color="white" />
                        </View>
                        <Text style={[styles.shortcutText, { color: theme.text }]}>Invite via group link</Text>
                    </TouchableOpacity>
                </>
            )}

            {/* Member list */}
            {displayedMembers.map((member) => (
                <View key={member._id} style={styles.row}>
                    <Image
                        source={{
                            uri: getImageUrl(member.profilePicture)
                                || `https://ui-avatars.com/api/?name=${encodeURIComponent(member.name || '?')}&background=3498db&color=fff&size=100`,
                        }}
                        style={styles.avatar}
                    />
                    <View style={{ flex: 1 }}>
                        <Text style={[styles.name, { color: theme.text }]}>{member.name}</Text>
                        <Text style={styles.about} numberOfLines={1}>
                            {member.mobile}
                        </Text>
                        {/* <Text style={styles.about} numberOfLines={1}>
                            {member.about || 'Hey there!'}
                        </Text> */}
                    </View>

                    <View style={styles.badges}>
                        {isAdminMember(member._id) && (
                            <View style={[styles.adminBadge, { backgroundColor: theme.batchColor }]}>
                                <Text style={styles.adminText}>{t('Assigned')}</Text>
                            </View>
                        )}
                        {/* Remove button — admin only, not self */}
                        {isAdmin && member._id !== MY_USER_ID && (
                            <TouchableOpacity
                                onPress={() => onRemoveMember(member)}
                                style={styles.removeBtn}
                            >
                                <Ionicons name="close" size={16} color="#e74c3c" />
                            </TouchableOpacity>
                        )}
                    </View>
                </View>
            ))}

            {/* View all / Show less */}
            {(groupDetails?.totalMembers || 0) > 5 && (
                <TouchableOpacity
                    style={[styles.viewAllBtn, { backgroundColor: theme.batchColor }]}
                    onPress={() => setShowAllMembers(!showAllMembers)}
                >
                    <Text style={styles.viewAllText}>
                        {showAllMembers
                            ? 'Show less'
                            : `View all (${groupDetails.totalMembers - 5} more)`}
                    </Text>
                </TouchableOpacity>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 15 },
    sectionTitle:  { fontSize: 17, fontWeight: '500' },
    row:           { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 15, paddingVertical: 10 },
    iconCircle:    { width: 46, height: 46, borderRadius: 23, backgroundColor: '#3498db', alignItems: 'center', justifyContent: 'center', marginRight: 15 },
    shortcutText:  { fontSize: 16, fontWeight: '500' },
    avatar:        { width: 46, height: 46, borderRadius: 23, marginRight: 15, backgroundColor: '#eee' },
    name:          { fontSize: 16, fontWeight: '600' },
    about:         { fontSize: 13, color: '#9f9f9f', marginTop: 2 },
    badges:        { flexDirection: 'row', alignItems: 'center', gap: 8 },
    adminBadge:    { backgroundColor: '#e1f5fe', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 5 },
    adminText:     { color: '#3498db', fontSize: 12, fontWeight: '700' },
    removeBtn:     { width: 28, height: 28, borderRadius: 14, backgroundColor: '#fff0f0', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#fdd' },
    viewAllBtn:    { paddingVertical: 10, paddingHorizontal: 25, borderRadius: 20, alignSelf: 'center', marginVertical: 15 },
    viewAllText:   { color: '#3498db', fontWeight: '500', fontSize: 14 },
});

export default GroupMembers;
