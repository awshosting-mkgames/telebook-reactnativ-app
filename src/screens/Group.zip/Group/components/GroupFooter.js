import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

const GroupFooter = ({ theme, isAdmin, onExitGroup, onDeleteGroup , onPriveChat }) => (
    <View>
        {/* Favorites */}
        <TouchableOpacity style={styles.item}>
            <View style={styles.iconCircle}>
                <Ionicons name="lock-closed" size={14} color="#000000" />
            </View>
            <Text style={[styles.text, { color: theme.text }]}>Lock Chat</Text>
        </TouchableOpacity>

        {/* Admin → Delete Group | Member → Exit Group */}
        {isAdmin ? (
            <TouchableOpacity style={styles.item} onPress={onDeleteGroup}>
                <View style={[styles.iconCircle, { backgroundColor: '#e74c3c' }]}>
                    <Ionicons name="trash-outline" size={18} color="#fff" />
                </View>
                <Text style={[styles.text, { color: '#e74c3c' }]}>Delete group</Text>
            </TouchableOpacity>
        ) : (
            <TouchableOpacity style={styles.item} onPress={onExitGroup}>
                <View style={[styles.iconCircle, { backgroundColor: '#ff1900' }]}>
                    <MaterialCommunityIcons name="exit-to-app" size={18} color="#fff" />
                </View>
                <Text style={[styles.text, { color: '#e74c3c' }]}>Exit group</Text>
            </TouchableOpacity>
        )}

        {/* Report */}
        <TouchableOpacity style={[styles.item, { marginBottom: 30 }]}>
            <View style={[styles.iconCircle, { backgroundColor: '#e74c3c' }]}>
                <Ionicons name="flag-outline" size={18} color="#fff" />
            </View>
            <Text style={[styles.text, { color: '#e74c3c' }]}>Report group</Text>
        </TouchableOpacity>
    </View>
);

const styles = StyleSheet.create({
    item:       { flexDirection: 'row', padding: 12, alignItems: 'center', marginBottom: 5 },
    iconCircle: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: '#3498db', marginRight: 8 },
    text:       { fontSize: 17, fontWeight: '600', marginLeft: 8 },
});

export default GroupFooter;
