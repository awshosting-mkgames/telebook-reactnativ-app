// src/index.js
import React, { useRef, useState, useEffect } from 'react';
import AppNavigator from './navigation';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import StatusBarComponent from './components/StatusBarcom';



export default function App() {
    
    console.log("App Loaded");
    return (
        <SafeAreaProvider>
            <StatusBarComponent />
            <AppNavigator />
        </SafeAreaProvider>
    );
}